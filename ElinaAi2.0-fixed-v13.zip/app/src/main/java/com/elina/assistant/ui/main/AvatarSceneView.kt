package com.elina.assistant.ui.main

import android.content.Context
import android.util.AttributeSet
import android.graphics.Color
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import com.elina.assistant.avatar.AvatarRenderer

class AvatarSceneView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    private var renderer: AvatarRenderer? = null
    private val fallback = TextView(context).apply {
        text = "ElinaAI"
        setTextColor(Color.WHITE)
        textSize = 22f
        gravity = Gravity.CENTER
        setBackgroundColor(Color.TRANSPARENT)
    }

    init {
        addView(fallback, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (renderer != null) return
        try {
            val created = AvatarRenderer(context)
            renderer = created
            addView(created.view(), LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            fallback.visibility = GONE
        } catch (_: Throwable) {
            // Keep the normal Android UI usable even when a device WebView is unavailable.
            fallback.visibility = VISIBLE
        }
    }

    fun setEmotion(name: String, strength: Float) = renderer?.setEmotion(name, strength)
    fun setLip(shape: String, amount: Float) = renderer?.setLip(shape, amount)
    fun blink() = renderer?.blink()
    fun lookAt(x: Float, y: Float) = renderer?.lookAt(x, y)

    fun release() {
        renderer?.release()
        renderer = null
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }
}
