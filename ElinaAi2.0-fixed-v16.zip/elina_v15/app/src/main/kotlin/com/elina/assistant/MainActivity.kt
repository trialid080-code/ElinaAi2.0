package com.elina.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.elina.assistant.chat.AvatarCommand
import com.elina.assistant.chat.ChatViewModel
import com.elina.assistant.chat.DialogState
import com.elina.assistant.data.AppDatabase
import com.elina.assistant.data.ChatRepository
import com.elina.assistant.databinding.ActivityMainBinding
import com.elina.assistant.llm.OpenAiCompatibleClient
import com.elina.assistant.rag.InMemoryRagRetriever
import com.elina.assistant.ui.AvatarBridge
import com.elina.assistant.ui.ChatAdapter
import com.elina.assistant.voice.AsrManager
import com.elina.assistant.voice.AndroidAsrManager
import com.elina.assistant.voice.AndroidTtsManager
import com.elina.assistant.voice.TtsManager
import com.elina.assistant.util.AppConfig
import com.elina.assistant.util.logI
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var avatarBridge: AvatarBridge
    private lateinit var chatAdapter: ChatAdapter

    private val viewModel: ChatViewModel by viewModels {
        val repo = ChatRepository(AppDatabase.get(applicationContext))
        val asr: AsrManager = AndroidAsrManager(applicationContext)
        val tts: TtsManager = AndroidTtsManager(applicationContext)
        ChatVmFactory(
            ChatViewModel(
                repo = repo,
                asr = asr,
                tts = tts,
                llm = OpenAiCompatibleClient(),
                rag = InMemoryRagRetriever(),
            )
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppConfig.load(this)
        setupAvatar()
        setupChatList()
        setupTopBar()
        setupPtt()
        setupTextInput()
        observeViewModel()
        ensureMicPermission()
        viewModel.ensureConversation()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupAvatar() {
        val webView = binding.avatarWebView
        // Serve bundled assets via virtual https origin so ES module imports
        // (importmap → CDN) work — file:// origin is "null" and CORS-blocked.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest,
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            mediaPlaybackRequiresUserGesture = false
        }
        webView.setBackgroundColor(0)
        avatarBridge = AvatarBridge(webView)
        webView.addJavascriptInterface(avatarBridge, "ElinaAIBridge")
        webView.loadUrl("https://appassets.androidplatform.net/assets/avatar/index.html")
    }

    private fun setupChatList() {
        chatAdapter = ChatAdapter()
        binding.chatRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply { stackFromEnd = true }
            adapter = chatAdapter
        }
    }

    private fun setupTopBar() {
        binding.topBar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }
                R.id.action_clear -> {
                    viewModel.clearCurrentConversation()
                    viewModel.ensureConversation()
                    true
                }
                R.id.action_settings -> {
                    showAiSettings()
                    true
                }
                else -> false
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupPtt() {
        binding.pttButton.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    viewModel.startListening()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    viewModel.stopListening()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupTextInput() {
        binding.sendButton.setOnClickListener {
            val text = binding.messageInput.text?.toString().orEmpty()
            if (text.isNotBlank()) {
                binding.messageInput.text?.clear()
                viewModel.sendText(text)
            }
        }
        binding.messageInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                binding.sendButton.performClick()
                true
            } else false
        }
    }

    private fun showAiSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 8, 40, 0)
        }
        fun field(value: String, hint: String, password: Boolean = false): EditText = EditText(this).apply {
            setText(value)
            this.hint = hint
            if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val url = field(AppConfig.llmBaseUrl, "Base URL")
        val key = field(AppConfig.llmApiKey, "Gemini API key", true)
        val model = field(AppConfig.llmModel, "Model")
        box.addView(url); box.addView(key); box.addView(model)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("ElinaAI settings")
            .setMessage("Gemini OpenAI-compatible API configuration")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                AppConfig.save(this, url.text.toString(), key.text.toString(), model.text.toString())
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.state.collect { state ->
                        binding.statusBar.text = when (state) {
                            DialogState.Idle -> getString(R.string.status_idle)
                            DialogState.Listening -> getString(R.string.status_listening)
                            DialogState.Thinking -> getString(R.string.status_thinking)
                            DialogState.Speaking -> getString(R.string.status_speaking)
                            is DialogState.Error -> getString(R.string.status_error, state.message)
                        }
                    }
                }

                launch {
                    viewModel.messages.collect { msgs ->
                        chatAdapter.submitList(msgs.filter { it.role.name != "SYSTEM" }) {
                            val last = chatAdapter.itemCount - 1
                            if (last >= 0) binding.chatRecyclerView.scrollToPosition(last)
                        }
                    }
                }

                launch {
                    viewModel.avatarCommands.collect { cmd ->
                        when (cmd) {
                            is AvatarCommand.SetEmotion -> avatarBridge.setEmotion(cmd.name)
                            is AvatarCommand.SetSpeaking -> avatarBridge.setSpeaking(cmd.active)
                            is AvatarCommand.Wave -> avatarBridge.wave()
                        }
                    }
                }
            }
        }
    }

    private fun ensureMicPermission() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
        }
    }
}

private class ChatVmFactory(private val vm: ChatViewModel) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = vm as T
}
