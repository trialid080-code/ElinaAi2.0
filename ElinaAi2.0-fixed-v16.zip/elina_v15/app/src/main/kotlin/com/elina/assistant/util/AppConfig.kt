package com.elina.assistant.util

import android.content.Context

/** Runtime configuration persisted inside app-private storage. */
object AppConfig {
    private const val PREFS = "elina_config"
    private const val KEY_URL = "llm_url"
    private const val KEY_API = "llm_api_key"
    private const val KEY_MODEL = "llm_model"

    var llmBaseUrl: String = "https://generativelanguage.googleapis.com/v1beta/openai/"
    var llmApiKey: String = ""
    var llmModel: String = "gemini-3.8-flash"

    var systemPrompt: String = """
        You are Elina, a warm, intelligent Android AI voice assistant and 3D VRM companion.
        Speak naturally and conversationally. Keep answers concise unless the user asks for detail.
        You can chat, remember conversation history, listen through the microphone, speak answers aloud,
        and control the Elina avatar with emotions and lip-sync.
        Never claim a device action succeeded unless the app confirms it.
        Do not pretend to be human or claim consciousness.
        Match the user's language automatically (Hindi, Hinglish, English, etc.).
    """.trimIndent()

    var ragEnabled: Boolean = false
    var contextWindow: Int = 24

    fun load(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        llmBaseUrl = p.getString(KEY_URL, llmBaseUrl) ?: llmBaseUrl
        llmApiKey = p.getString(KEY_API, "") ?: ""
        llmModel = p.getString(KEY_MODEL, llmModel) ?: llmModel
    }

    fun save(context: Context, baseUrl: String, apiKey: String, model: String) {
        llmBaseUrl = baseUrl.trim().ifBlank { "https://generativelanguage.googleapis.com/v1beta/openai/" }
        llmApiKey = apiKey.trim()
        llmModel = model.trim().ifBlank { "gemini-3.8-flash" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_URL, llmBaseUrl)
            .putString(KEY_API, llmApiKey)
            .putString(KEY_MODEL, llmModel)
            .apply()
    }
}
