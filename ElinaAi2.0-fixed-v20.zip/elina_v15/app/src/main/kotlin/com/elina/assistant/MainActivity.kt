package com.elina.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.elina.assistant.chat.AvatarCommand
import com.elina.assistant.chat.ChatViewModel
import com.elina.assistant.data.AppDatabase
import com.elina.assistant.data.ChatRepository
import com.elina.assistant.databinding.ActivityMainBinding
import com.elina.assistant.device.DeviceActionExecutor
import com.elina.assistant.live.GeminiLiveManager
import com.elina.assistant.memory.MemoryStore
import com.elina.assistant.service.ElinaAccessibilityService
import com.elina.assistant.service.WakeWordService
import com.elina.assistant.ui.AvatarBridge
import com.elina.assistant.ui.ChatAdapter
import com.elina.assistant.util.AppConfig
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var avatarBridge: AvatarBridge
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var viewModel: ChatViewModel
    private lateinit var live: GeminiLiveManager
    private var liveActive = false
    private var wakeEnabled = false

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) toast("Microphone permission is required for live voice.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        createViewModel()
        setupAvatar()
        setupChatList()
        setupTopBar()
        setupLiveButton()
        setupTextInput()
        observeViewModel()
        ensureMicPermission()
        viewModel.ensureConversation()
        if (intent.getBooleanExtra("WAKE_UP", false)) {
            window.decorView.postDelayed({
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    if (!liveActive) binding.liveButton.performClick()
                }
            }, 500)
        }
    }

    private fun createViewModel() {
        val repo = ChatRepository(AppDatabase.get(applicationContext))
        val memory = MemoryStore(applicationContext)
        val device = DeviceActionExecutor(applicationContext)
        live = GeminiLiveManager(
            apiKeyProvider = { AppConfig.llmApiKey },
            memoryStore = memory,
            deviceActions = device,
            callback = object : GeminiLiveManager.Callback {
                override fun onAudioLevel(level: Float) = runOnUiThread { avatarBridge.setMouthLevel(level) }
                override fun onState(state: GeminiLiveManager.State) {
                    runOnUiThread {
                        when (state) {
                            GeminiLiveManager.State.CONNECTING -> binding.statusBar.text = "Connecting to Elina…"
                            GeminiLiveManager.State.LISTENING -> binding.statusBar.text = "Listening — you can interrupt anytime"
                            GeminiLiveManager.State.THINKING -> binding.statusBar.text = "Thinking…"
                            GeminiLiveManager.State.SPEAKING -> binding.statusBar.text = "Elina is speaking — talk to interrupt"
                            GeminiLiveManager.State.INTERRUPTED -> binding.statusBar.text = "Interrupted — listening"
                            GeminiLiveManager.State.DISCONNECTED -> binding.statusBar.text = getString(R.string.status_idle)
                        }
                    }
                    when (state) {
                        GeminiLiveManager.State.SPEAKING -> runOnUiThread { viewModel.onLiveSpeaking() }
                        GeminiLiveManager.State.INTERRUPTED -> runOnUiThread { viewModel.onLiveInterrupted() }
                        GeminiLiveManager.State.LISTENING -> runOnUiThread { binding.liveButton.isSelected = true }
                        else -> Unit
                    }
                }
                override fun onUserTranscript(text: String) = runOnUiThread { viewModel.onLiveUserTranscript(text) }
                override fun onAssistantTranscript(text: String) = runOnUiThread { viewModel.onLiveAssistantTranscript(text) }
                override fun onAvatarEmotion(name: String) = runOnUiThread { avatarBridge.setEmotion(name) }
                override fun onToolResult(name: String, result: String) = runOnUiThread { viewModel.onToolResult(name, result) }
                override fun onError(message: String) = runOnUiThread { viewModel.onLiveStateError(message) }
                override fun onConnected() = runOnUiThread { viewModel.onLiveConnected() }
            }
        )
        viewModel = ChatViewModel(repo, live)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun setupAvatar() {
        val webView = binding.avatarWebView
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = false
        webView.setBackgroundColor(0)
        avatarBridge = AvatarBridge(webView)
        webView.addJavascriptInterface(avatarBridge, "ElinaAIBridge")
        val assetLoader = androidx.webkit.WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(view: android.webkit.WebView, request: android.webkit.WebResourceRequest) = assetLoader.shouldInterceptRequest(request.url)
        }
        webView.loadUrl("https://appassets.androidplatform.net/assets/avatar/index.html")
    }

    private fun setupChatList() {
        chatAdapter = ChatAdapter()
        binding.chatRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply { stackFromEnd = true }
            adapter = chatAdapter
        }
    }

    private fun setupTopBar() {
        binding.topBar.setOnMenuItemClickListener { item -> handleMenu(item) }
    }

    private fun handleMenu(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_history -> {
            startActivity(Intent(this, HistoryActivity::class.java)); true
        }
        R.id.action_clear -> {
            viewModel.clearCurrentConversation(); true
        }
        R.id.action_settings -> {
            showSettings(); true
        }
        R.id.action_device_controls -> {
            if (ElinaAccessibilityService.instance == null) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else toast("Device control is enabled.")
            true
        }
        R.id.action_wake_word -> {
            toggleWakeWord(); true
        }
        R.id.action_memory -> {
            showMemoryInfo(); true
        }
        else -> false
    }

    private fun setupLiveButton() {
        binding.liveButton.setOnClickListener {
            if (!liveActive) {
                ensureMicPermission()
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    liveActive = true
                    binding.liveButton.isSelected = true
                    binding.liveButton.text = getString(R.string.stop_live_label)
                    viewModel.startLive()
                    animateLive(true)
                }
            } else {
                liveActive = false
                binding.liveButton.isSelected = false
                binding.liveButton.text = getString(R.string.start_live_label)
                viewModel.stopLive()
                animateLive(false)
            }
        }
    }

    private fun animateLive(active: Boolean) {
        val scale = if (active) 1.03f else 1f
        binding.avatarContainer.animate().scaleX(scale).scaleY(scale).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        binding.liveButton.animate().alpha(if (active) 1f else 0.88f).setDuration(180).start()
    }

    private fun setupTextInput() {
        binding.sendButton.setOnClickListener {
            val text = binding.messageInput.text?.toString().orEmpty().trim()
            if (text.isNotBlank()) {
                binding.messageInput.text?.clear()
                viewModel.sendText(text)
            }
        }
        binding.messageInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                binding.sendButton.performClick(); true
            } else false
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        fun field(value: String, hint: String, password: Boolean = false) = EditText(this).apply {
            setText(value); this.hint = hint
            if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val key = field(AppConfig.llmApiKey, "Gemini API key", true)
        val model = field(AppConfig.liveModel, "Live model")
        val voice = field(AppConfig.liveVoice, "Live voice (for example Kore)")
        box.addView(key); box.addView(model); box.addView(voice)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Elina settings")
            .setMessage("Live voice uses Gemini Live API. The API key is stored only in app-private storage.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                AppConfig.save(this, AppConfig.llmBaseUrl, key.text.toString(), AppConfig.llmModel)
                AppConfig.saveLiveModel(this, model.text.toString())
                AppConfig.saveLiveVoice(this, voice.text.toString())
                toast("Saved. Start a new Live session to reconnect.")
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun toggleWakeWord() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ensureMicPermission(); return
        }
        wakeEnabled = !wakeEnabled
        val i = Intent(this, WakeWordService::class.java)
        if (wakeEnabled) {
            ContextCompat.startForegroundService(this, i)
            toast("Wake word enabled. Say Hey Elina.")
        } else {
            stopService(i)
            toast("Wake word disabled.")
        }
    }

    private fun showMemoryInfo() {
        val summary = MemoryStore(this).summary(30)
        AlertDialog.Builder(this)
            .setTitle("Elina memory")
            .setMessage(summary)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.state.collect { state ->
                        if (state is com.elina.assistant.chat.DialogState.Error) binding.statusBar.text = state.message
                    }
                }
                launch {
                    viewModel.messages.collect { msgs ->
                        chatAdapter.submitList(msgs.filter { it.role.name != "SYSTEM" }) {
                            val last = chatAdapter.itemCount - 1
                            if (last >= 0) binding.chatRecyclerView.scrollToPosition(last)
                        }
                    }
                }
                launch {
                    viewModel.avatarCommands.collect { cmd ->
                        when (cmd) {
                            is AvatarCommand.SetEmotion -> avatarBridge.setEmotion(cmd.name)
                            is AvatarCommand.SetSpeaking -> avatarBridge.setSpeaking(cmd.active)
                            is AvatarCommand.Wave -> avatarBridge.wave()
                            is AvatarCommand.Tool -> avatarBridge.setEmotion(if (cmd.result.contains("failed", true)) "error" else "happy")
                        }
                    }
                }
            }
        }
    }

    private fun ensureMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
