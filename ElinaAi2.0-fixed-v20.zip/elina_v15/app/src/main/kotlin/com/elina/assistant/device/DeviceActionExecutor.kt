package com.elina.assistant.device

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.elina.assistant.service.ElinaAccessibilityService

/** Safe, small set of actions exposed to the model. */
class DeviceActionExecutor(private val context: Context) {
    fun accessibilityEnabled(): Boolean = ElinaAccessibilityService.instance != null

    fun openAccessibilitySettings() {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun execute(action: String, args: Map<String, Any?>): String {
        val service = ElinaAccessibilityService.instance
        return when (action) {
            "back" -> service?.globalBack() ?: "Accessibility service is not enabled."
            "home" -> service?.globalHome() ?: "Accessibility service is not enabled."
            "recents" -> service?.globalRecents() ?: "Accessibility service is not enabled."
            "tap" -> {
                if (service == null) "Accessibility service is not enabled."
                else service.tap(
                    args["x"]?.toString()?.toFloatOrNull() ?: return "Invalid x.",
                    args["y"]?.toString()?.toFloatOrNull() ?: return "Invalid y."
                )
            }
            "swipe" -> {
                if (service == null) "Accessibility service is not enabled."
                else service.swipe(
                    args["x1"]?.toString()?.toFloatOrNull() ?: return "Invalid x1.",
                    args["y1"]?.toString()?.toFloatOrNull() ?: return "Invalid y1.",
                    args["x2"]?.toString()?.toFloatOrNull() ?: return "Invalid x2.",
                    args["y2"]?.toString()?.toFloatOrNull() ?: return "Invalid y2.",
                    args["durationMs"]?.toString()?.toLongOrNull()?.coerceIn(100, 2000) ?: 350L
                )
            }
            "swipe_left", "swipe_right", "swipe_up", "swipe_down" -> {
                if (service == null) "Accessibility service is not enabled."
                else {
                    val w = context.resources.displayMetrics.widthPixels.toFloat()
                    val h = context.resources.displayMetrics.heightPixels.toFloat()
                    val cx = w / 2f
                    val cy = h / 2f
                    val dx = w * 0.38f
                    val dy = h * 0.32f
                    val (x1, y1, x2, y2) = when (action) {
                        "swipe_left" -> listOf(cx + dx, cy, cx - dx, cy)
                        "swipe_right" -> listOf(cx - dx, cy, cx + dx, cy)
                        "swipe_up" -> listOf(cx, cy + dy, cx, cy - dy)
                        else -> listOf(cx, cy - dy, cx, cy + dy)
                    }
                    service.swipe(x1, y1, x2, y2, args["durationMs"]?.toString()?.toLongOrNull()?.coerceIn(100, 2000) ?: 350L)
                }
            }
            "click_text" -> {
                if (service == null) "Accessibility service is not enabled."
                else service.clickText(args["text"]?.toString().orEmpty())
            }
            "type_text" -> {
                if (service == null) "Accessibility service is not enabled."
                else service.typeText(args["text"]?.toString().orEmpty())
            }
            "open_url" -> {
                val url = args["url"]?.toString().orEmpty().trim()
                if (url.isBlank()) "Missing URL."
                else try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Opened URL."
                } catch (e: Exception) {
                    "Could not open URL: ${e.message}"
                }
            }
            "open_app" -> openApp(args["package"]?.toString().orEmpty())
            else -> "Unknown device action: $action"
        }
    }

    private fun String.toFloatOrNull(): Float? = trim().toFloatOrNull()
    private fun String.toLongOrNull(): Long? = trim().toLongOrNull()

    private fun openApp(packageName: String): String {
        if (packageName.isBlank()) return "Missing package name."
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?: return "App not found: $packageName"
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            "Opened $packageName."
        } catch (e: Exception) {
            "Could not open app: ${e.message}"
        }
    }
}
