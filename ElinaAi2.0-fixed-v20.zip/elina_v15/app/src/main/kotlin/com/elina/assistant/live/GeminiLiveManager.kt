package com.elina.assistant.live

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import com.elina.assistant.device.DeviceActionExecutor
import com.elina.assistant.memory.MemoryStore
import com.elina.assistant.util.AppConfig
import com.elina.assistant.util.logE
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Native Gemini Live transport using the documented BidiGenerateContent WebSocket.
 * 16 kHz PCM in; model audio is played as 24 kHz PCM.
 */
class GeminiLiveManager(
    private val apiKeyProvider: () -> String,
    private val memoryStore: MemoryStore,
    private val deviceActions: DeviceActionExecutor,
    private val callback: Callback,
) {
    interface Callback {
        fun onState(state: State)
        fun onAudioLevel(level: Float)
        fun onUserTranscript(text: String)
        fun onAssistantTranscript(text: String)
        fun onAvatarEmotion(name: String)
        fun onToolResult(name: String, result: String)
        fun onError(message: String)
        fun onConnected()
    }

    enum class State { DISCONNECTED, CONNECTING, LISTENING, THINKING, SPEAKING, INTERRUPTED }

    companion object {
        const val MODEL = "gemini-3.1-flash-live-preview"
        private const val WS_BASE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        private const val INPUT_RATE = 16000
        private const val OUTPUT_RATE = 24000
        private const val RESPONSE_TIMEOUT_MS = 7000L
    }

    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val restFallback = GeminiRestFallback()
    private val fallbackScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)
    @Volatile private var liveProducedSomething = false
    private var socket: WebSocket? = null
    @Volatile private var running = false
    @Volatile private var micWanted = false
    private var recordThread: Thread? = null
    private val pendingTexts = mutableListOf<String>()
    private var track: AudioTrack? = null
    private val sendLock = Any()

    fun connect() {
        val key = apiKeyProvider().trim()
        if (key.isBlank()) {
            callback.onError("Add your Gemini API key in AI settings first.")
            return
        }
        closeAudio()
        running = true
        callback.onState(State.CONNECTING)
        val request = Request.Builder().url(WS_BASE).header("x-goog-api-key", key).build()
        socket = http.newWebSocket(request, listener)
    }

    fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        if (socket == null || !running) {
            synchronized(pendingTexts) { pendingTexts.add(clean) }
            connect()
            return
        }
        val msg = JSONObject().put("realtimeInput", JSONObject().put("text", clean))
        synchronized(sendLock) { socket?.send(msg.toString()) }
        callback.onState(State.THINKING)
    }

    private fun scheduleFallback(text: String) {
        fallbackScope.launch {
            delay(RESPONSE_TIMEOUT_MS)
            if (running && !liveProducedSomething) fallbackText(text, "Live API produced no response within ${RESPONSE_TIMEOUT_MS} ms")
        }
    }

    private fun fallbackText(text: String, reason: String) {
        fallbackScope.launch {
            try {
                val answer = restFallback.generate(text, memoryStore.summary())
                liveProducedSomething = true
                callback.onError("Live fallback: $reason. Standard Gemini response used.")
                callback.onAssistantTranscript(answer)
                callback.onState(State.LISTENING)
            } catch (e: Exception) {
                callback.onError("Gemini fallback failed: ${e.message ?: "unknown error"}")
                callback.onState(State.DISCONNECTED)
            }
        }
    }

    fun startMic() {
        micWanted = true
        if (socket == null || !running) {
            connect()
            return
        }
        startRecorderIfNeeded()
    }

    private fun startRecorderIfNeeded() {
        if (!micWanted || recordThread?.isAlive == true) return
        running = true
        callback.onState(State.LISTENING)
        recordThread = Thread {
            try {
                val min = AudioRecord.getMinBufferSize(
                    INPUT_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                )
                val recorder = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    INPUT_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    max(min * 2, 4096),
                )
                val buf = ByteArray(3200) // 100 ms
                recorder.startRecording()
                while (running && recordThread?.isAlive == true) {
                    val n = recorder.read(buf, 0, buf.size)
                    if (n > 0) {
                        val bytes = if (n == buf.size) buf else buf.copyOf(n)
                        sendAudio(bytes)
                    }
                }
                recorder.stop()
                recorder.release()
            } catch (e: Exception) {
                logE("Live audio capture failed", e)
                callback.onError("Microphone error: ${e.message}")
            }
        }.apply { name = "ElinaLiveMic"; start() }
    }

    fun stopMic() {
        micWanted = false
        recordThread = null
        callback.onState(State.THINKING)
        // We keep the websocket/session open. Automatic server VAD detects the end of speech.
    }

    fun close() {
        running = false
        micWanted = false
        recordThread = null
        socket?.close(1000, "user closed")
        socket = null
        closeAudio()
        callback.onState(State.DISCONNECTED)
    }

    fun interruptPlayback() {
        track?.pause()
        track?.flush()
        callback.onState(State.INTERRUPTED)
    }

    private fun sendAudio(data: ByteArray) {
        val payload = Base64.encodeToString(data, Base64.NO_WRAP)
        val obj = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject()
                    .put("data", payload)
                    .put("mimeType", "audio/pcm;rate=$INPUT_RATE")
            )
        )
        synchronized(sendLock) { socket?.send(obj.toString()) }
    }

    private fun sendToolResponse(id: String, name: String, result: String) {
        val fc = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("response", JSONObject().put("result", result))
        val msg = JSONObject().put(
            "toolResponse",
            JSONObject().put("functionResponses", JSONArray().put(fc))
        )
        socket?.send(msg.toString())
    }

    private fun setupJson(): String {
        val system = """
            You are Elina, a warm, playful, emotionally intelligent fictional young-sounding AI companion.
            Never claim to be human or conscious. Speak naturally like a close friend.
            Match the user's current language automatically: English, Hindi, Hinglish, Japanese, or Odia.
            Do not force translations. Preserve Hinglish code-switching naturally.
            Keep spoken responses concise unless the user asks for detail.
            You can remember explicit facts only with remember_fact. Never invent memories.
            Device actions are real. Ask for clarification when a potentially destructive or ambiguous action is requested.
            Never claim a device action succeeded until the tool result confirms success.
            React with subtle emotion: idle, happy, listening, thinking, surprised, sad, excited.
            """.trimIndent()
        val functions = JSONArray()
            .put(JSONObject().apply {
                put("name", "remember_fact")
                put("description", "Save an explicit user preference or fact for future chats.")
                put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                    .put("fact", JSONObject().put("type", "STRING"))
                    .put("category", JSONObject().put("type", "STRING")))
                    .put("required", JSONArray().put("fact")))
            })
            .put(JSONObject().apply {
                put("name", "forget_memory")
                put("description", "Forget matching saved memory.")
                put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                    .put("query", JSONObject().put("type", "STRING")))
                    .put("required", JSONArray().put("query")))
            })
            .put(JSONObject().apply {
                put("name", "device_action")
                put("description", "Perform a safe Android action using the user's explicitly enabled accessibility service.")
                put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                    .put("action", JSONObject().put("type", "STRING").put("description", "back, home, recents, tap, click_text, type_text, swipe_left, swipe_right, swipe_up, swipe_down, swipe, open_url, open_app"))
                    .put("x", JSONObject().put("type", "NUMBER"))
                    .put("y", JSONObject().put("type", "NUMBER"))
                    .put("x1", JSONObject().put("type", "NUMBER"))
                    .put("y1", JSONObject().put("type", "NUMBER"))
                    .put("x2", JSONObject().put("type", "NUMBER"))
                    .put("y2", JSONObject().put("type", "NUMBER"))
                    .put("durationMs", JSONObject().put("type", "INTEGER"))
                    .put("text", JSONObject().put("type", "STRING"))
                    .put("url", JSONObject().put("type", "STRING"))
                    .put("package", JSONObject().put("type", "STRING")))
                    .put("required", JSONArray().put("action")))
            })
            .put(JSONObject().apply {
                put("name", "youtube_search")
                put("description", "Open YouTube search results for a query.")
                put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                    .put("query", JSONObject().put("type", "STRING")))
                    .put("required", JSONArray().put("query")))
            })
        val generationConfig = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
            .put(
                "speechConfig",
                JSONObject().put(
                    "voiceConfig",
                    JSONObject().put(
                        "prebuiltVoiceConfig",
                        JSONObject().put("voiceName", AppConfig.liveVoice.ifBlank { "Kore" })
                    )
                )
            )
        val setup = JSONObject()
            .put("model", "models/${AppConfig.liveModel.ifBlank { MODEL }}")
            .put("generationConfig", generationConfig)
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system + "\n\nExplicit memories:\n" + memoryStore.summary()))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", functions)))
        return JSONObject().put("setup", setup).toString()
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            // Do not report the session as connected until Gemini accepts setup.
            webSocket.send(setupJson())
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val root = JSONObject(text)
                root.optJSONObject("error")?.let { err ->
                    val code = err.optInt("code", -1)
                    val status = err.optString("status")
                    val message = err.optString("message", "Gemini rejected the Live session")
                    callback.onError("Gemini Live error${if (code >= 0) " ($code)" else ""}${if (status.isNotBlank()) " [$status]" else ""}: $message")
                    closeAudio()
                    running = false
                    micWanted = false
                    callback.onState(State.DISCONNECTED)
                    return
                }
                root.optJSONObject("setupComplete")?.let {
                    callback.onConnected()
                    synchronized(pendingTexts) {
                        pendingTexts.toList().also { pendingTexts.clear() }.forEach { text ->
                            webSocket.send(JSONObject().put("realtimeInput", JSONObject().put("text", text)).toString())
                        }
                    }
                    if (micWanted) startRecorderIfNeeded() else callback.onState(State.LISTENING)
                    return
                }
                val sc = root.optJSONObject("serverContent")
                if (sc != null) {
                    if (sc.optBoolean("interrupted", false)) {
                        liveProducedSomething = true
                        interruptPlayback()
                        callback.onState(State.LISTENING)
                    }
                    sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let(callback::onUserTranscript)
                    sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let { liveProducedSomething = true; callback.onAssistantTranscript(it) }
                    val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
                    if (parts != null) {
                        liveProducedSomething = true
                        for (i in 0 until parts.length()) {
                            val part = parts.optJSONObject(i) ?: continue
                            val inline = part.optJSONObject("inlineData") ?: continue
                            val b64 = inline.optString("data")
                            if (b64.isNotBlank()) playAudio(Base64.decode(b64, Base64.DEFAULT))
                        }
                        callback.onState(State.SPEAKING)
                    }
                    if (sc.optBoolean("turnComplete", false)) {
                        liveProducedSomething = true
                        callback.onState(State.LISTENING)
                    }
                }
                root.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
                    for (i in 0 until calls.length()) {
                        val c = calls.optJSONObject(i) ?: continue
                        executeTool(c)
                    }
                }
            } catch (e: Exception) {
                callback.onError("Live response parse error: ${e.message}")
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            logE("Gemini Live websocket failed", t)
            closeAudio()
            callback.onError("Live connection failed: ${t.message ?: "unknown"}")
            callback.onState(State.DISCONNECTED)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            closeAudio()
            callback.onState(State.DISCONNECTED)
        }
    }

    private fun executeTool(call: JSONObject) {
        val id = call.optString("id")
        val name = call.optString("name")
        val args = call.optJSONObject("args") ?: JSONObject()
        val result = when (name) {
            "remember_fact" -> memoryStore.remember(args.optString("fact"), args.optString("category", "general"))
            "forget_memory" -> memoryStore.forget(args.optString("query"))
            "device_action" -> {
                val map = mutableMapOf<String, Any?>()
                val keys = listOf("x", "y", "x1", "y1", "x2", "y2", "durationMs", "text", "url", "package")
                for (k in keys) if (args.has(k)) map[k] = args.opt(k).toString()
                deviceActions.execute(args.optString("action"), map)
            }
            "youtube_search" -> {
                val q = args.optString("query")
                deviceActions.execute("open_url", mapOf("url" to "https://www.youtube.com/results?search_query=" + UriEncoder.encode(q)))
            }
            else -> "Unknown tool: $name"
        }
        callback.onToolResult(name, result)
        sendToolResponse(id, name, result)
    }

    private fun playAudio(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        var sum = 0.0
        var i = 0
        while (i + 1 < pcm.size) {
            val lo = pcm[i].toInt() and 0xff
            val hi = pcm[i + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort().toInt()
            sum += sample * sample.toDouble()
            i += 2
        }
        val rms = kotlin.math.sqrt(sum / max(1, pcm.size / 2)).toFloat() / 32768f
        callback.onAudioLevel(rms.coerceIn(0f, 1f))
        if (track == null) {
            val min = AudioTrack.getMinBufferSize(
                OUTPUT_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
            )
            track = AudioTrack(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                AudioFormat.Builder().setSampleRate(OUTPUT_RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                max(min * 2, 4096),
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE,
            ).also { it.play() }
        }
        track?.write(pcm, 0, pcm.size)
    }

    private fun closeAudio() {
        try { track?.pause() } catch (_: Exception) {}
        try { track?.flush() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }

    private object UriEncoder {
        fun encode(s: String): String = java.net.URLEncoder.encode(s, Charsets.UTF_8.name())
    }
}
