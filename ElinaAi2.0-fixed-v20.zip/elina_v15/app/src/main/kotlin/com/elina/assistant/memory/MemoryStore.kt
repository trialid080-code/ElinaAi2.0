package com.elina.assistant.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small durable explicit-memory store. Facts are only saved when Elina explicitly decides to remember them. */
class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("elina_memory", Context.MODE_PRIVATE)

    @Synchronized
    fun remember(fact: String, category: String = "general"): String {
        val clean = fact.trim().take(500)
        if (clean.isBlank()) return "Nothing to remember."
        val arr = JSONArray(prefs.getString("items", "[]"))
        val now = System.currentTimeMillis()
        var replaced = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("fact").equals(clean, ignoreCase = true)) {
                o.put("category", category.ifBlank { "general" })
                o.put("updatedAt", now)
                replaced = true
                break
            }
        }
        if (!replaced) {
            arr.put(JSONObject().apply {
                put("fact", clean)
                put("category", category.ifBlank { "general" })
                put("updatedAt", now)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
        return if (replaced) "Memory updated." else "Memory saved."
    }

    @Synchronized
    fun forget(query: String): String {
        val q = query.trim()
        if (q.isBlank()) return "Tell me what to forget."
        val old = JSONArray(prefs.getString("items", "[]"))
        val out = JSONArray()
        var removed = 0
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            val fact = o.optString("fact")
            if (fact.contains(q, ignoreCase = true)) removed++ else out.put(o)
        }
        prefs.edit().putString("items", out.toString()).apply()
        return if (removed > 0) "Memory removed." else "I couldn't find a matching memory."
    }

    @Synchronized
    fun clear() {
        prefs.edit().clear().apply()
    }

    fun summary(maxItems: Int = 20): String {
        val arr = JSONArray(prefs.getString("items", "[]"))
        if (arr.length() == 0) return "(no explicit memories yet)"
        val start = maxOf(0, arr.length() - maxItems)
        return buildString {
            for (i in start until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                append("- [")
                append(o.optString("category", "general"))
                append("] ")
                append(o.optString("fact"))
                append('\n')
            }
        }.trim()
    }
}
