package com.elina.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import java.util.Locale

class AndroidTtsManager(private val context: Context) : TtsManager {
    private val _events = MutableSharedFlow<TtsEvent>(extraBufferCapacity = 16)
    override val events: SharedFlow<TtsEvent> = _events
    private var tts: TextToSpeech? = null
    private val pending = StringBuilder()

    override suspend fun init() {
        if (tts != null) return
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _events.tryEmit(TtsEvent.SpeakingStart(utteranceId.orEmpty())) }
                    override fun onDone(utteranceId: String?) { _events.tryEmit(TtsEvent.SpeakingEnd) }
                    override fun onError(utteranceId: String?) { _events.tryEmit(TtsEvent.Error("TTS error")) }
                })
            } else {
                _events.tryEmit(TtsEvent.Error("Android TTS unavailable"))
            }
        }
    }

    override fun feed(textChunk: String) { pending.append(textChunk); drain(false) }

    override fun flush() { drain(true) }

    private fun drain(force: Boolean) {
        while (true) {
            val cut = pending.indexOfAny(charArrayOf('.', '!', '?', '。', '！', '？', '\n'))
            if (cut < 0) break
            val sentence = pending.substring(0, cut + 1).trim()
            pending.delete(0, cut + 1)
            speak(sentence)
        }
        if (force && pending.isNotBlank()) {
            val sentence = pending.toString().trim()
            pending.clear()
            speak(sentence)
        }
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        val engine = tts ?: return
        engine.speak(text, TextToSpeech.QUEUE_ADD, null, "elina-${System.nanoTime()}")
    }

    override fun interrupt() { tts?.stop(); pending.clear() }

    override fun release() { tts?.stop(); tts?.shutdown(); tts = null; pending.clear() }
}
